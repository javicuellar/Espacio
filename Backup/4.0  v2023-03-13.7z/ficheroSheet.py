# -*- coding: utf-8 -*-
# Proyecto ESPACIO 4.0 - Analizador de discos (unidades, carpetas, usbs)
# ======================================================================
#  Importamos librerías para manejar las hojas de google y el drive
import gspread
from oauth2client.service_account import ServiceAccountCredentials

#   Definir el límite de acceso, el scope = alcance, acceso a hojas de cálculo y drive
alcance =  ['https://www.googleapis.com/auth/spreadsheets',
            'https://www.googleapis.com/auth/drive']

Credenciales = ServiceAccountCredentials.from_json_keyfile_name('./Fuentes/Credenciales.json', alcance)

cliente = gspread.authorize(Credenciales)

# Paquetes del proyecto
import mapeo	as c	 # Contiene funciones para mapear una línea de un fichero, mapear palabras


fileSheet = u'Bitácora Discos'
sheetInforme = u'Informe'
sheetUnidades = u'Discos'
sheetDirectorios = u'Directorios'
sheetBackup = u'Backup'


class FileSheet():
	def __init__(self, modo, tipo='T'):
		#  Intentamos crear abrir la hoja, si no existe la creamos
		try:
			self.hoja = cliente.open(fileSheet)
		except:
			#  No se ha podido abrir, vamos a crear la hoja
			self.hoja = cliente.create(fileSheet)
			print(" -> Se crea la hoja de cálculo google Bitácora Discos")
			#  Lo comparto con mi usuario
			self.hoja.share('javicu25@gmail.com', perm_type='user', role='writer')

		self.lista_inf = []
		self.modo = modo
		if modo == 'a':
			print(" -> No implementada pestaña backup")
		if tipo == 'U':
			try:
				self.pestaña = self.hoja.worksheet(sheetUnidades)
			except:
				#  Si no hemos podido abrirla, no existe, la creamos
				self.pestaña = self.hoja.add_worksheet(sheetUnidades, rows=100, cols=20)
		elif tipo == 'D':
			try:
				self.pestaña = self.hoja.worksheet(sheetDirectorios)
			except:
				self.pestaña = self.hoja.add_worksheet(sheetDirectorios, rows=100, cols=20)
		else:
			try:
				self.pestaña = self.hoja.worksheet(sheetInforme)
			except:
				self.pestaña = self.hoja.add_worksheet(sheetInforme, rows=100, cols=20)
		
		if modo == 'w' or modo == 'a':		# Grabar información en pestaña
			if tipo == 'T':
				# Grabamos la cabecera de las columnas del fichero .CSV
				cabecera = ('Tipo', 'Nivel Dir', 'Disco', 'Directorio', 'Nombre', 'Fecha Mod.', 'Ficheros',
							'Directorios', 'Tamaño', 'Bytes', 'Libre', 'Fecha', 'Error')
			elif tipo == 'D':
				# Formato salida: [f. analisis, volumen, directorio, tamaño, fecha modificación,  
				# num. ficheros, num. directorios, Nivel dir, error
				cabecera = ('Fecha', 'Disco', 'Directorio', 'Tamaño', 'Fecha Mod.', 
							'Ficheros', 'Directorios', 'Nivel Dir', 'Error')
			else:
				# Formato salida: [f. analisis, volumen, directorio, tamaño, fecha modificación,  
				# num. ficheros, num. directorios, espacio libre, error
				cabecera = ('Fecha', 'Disco', 'Directorio', 'Tamaño', 'Fecha Mod.', 
							'Ficheros', 'Directorios', 'Libre', 'Error')
			
			self.lista_inf.append(cabecera)
		else:
			self.lista_inf = self.pestaña.get_all_values()
			self.contador = 0

			
	def Leer_registro(self):
		try:
			self.contador += 1
			return self.lista_inf[self.contador - 1]
		except:
			#  habría que borrar la variable lista_inf para optimizar memoria
			return ''


	def escribir_registro(self, registro):
		self.lista_inf.append(registro)



	def Grabar_CSV(self, lista, tipo):
		# Formateamos la salida dependiendo si es información de Unidad, Directorio o Archivo
		for reg in lista:
			if reg[0] == 'U':	   # Contiene info unidad.: volumen, espacio_libre, fecha uditoria
				vol, err = c.mapeo_string(reg[1])
				libre = reg[2]
				faudit = reg[3]
			elif reg[0] == 'D':	   # contiene info dir....: path, fechamod, numfiles, numdir, tamano, error, nivel
				if tipo == 'T' 	or (libre != 0 and tipo == 'U')    										\
								or (libre == 0 and tipo == 'D' and reg[6] != ' (Acceso Denegado)'):	    \
					self.escribir_registro(formato_directorio(reg, vol, libre, faudit, tipo))
				
				ruta, err = c.mapeo_string(reg[1])
				libre = 0
			elif reg[0] == 'A':	   # contiene info archivo:  nombre, extension, fechamod, tamano, tipo, error, nivel
				self.escribir_registro(formato_archivo(reg, vol, faudit, ruta))
			else:
				print ('Info de unidad errónea al formatear salida a csv.')


	def __del__(self):
		#  Grabar la información si modo es escritura (w o a) 
		if self.modo == 'w' or self.modo == 'a':
			self.pestaña.update(self.lista_inf)
		#  Borrar la lista con la información
		del self.lista_inf

				



def Info_unidad(reg):
	# Clase Unidad: volumen, espacio_libre, fechaudit
	return reg[2], int(reg[13]), reg[11]
	
def Info_directorio(reg):
	# Clase Directorio: path, fechamod, numfiles, numdir, tamano, error
	return reg[3], reg[5], int(reg[6]), int(reg[7]), int(reg[9]), reg[12]

def Info_fichero(reg):
	nombre, extension = os.path.splitext(reg[4])
	# Clase Fichero: nombre, extension, tipo, fechamod, tamano, error
	return nombre, extension, reg[10], reg[5], int(reg[9]), reg[12]

		

def formato_archivo(infoarchivo, vol, faudit, ruta):
	# Info archivo: nombre, extension, fechamod, tamano, tipo, error, nivel
	nombre, err = c.mapeo_string(infoarchivo[1]+infoarchivo[2])
	if infoarchivo[6] == '' and err != '':
		infoarchivo[6] = err

	if infoarchivo[4] < 1024*1024*1024:
		tam = str(infoarchivo[4])
	else:
		tam = '%.2f' % (infoarchivo[4]/(1024*1024*1024)) + ' GB.'
	
	# Formato salida: ['U', nivel dir., volumen, directorio, nombre completo, fecha modificación,  
	# 		num. ficheros y dir. vacío, tamaño formateado, tamaño, tipo archivo y fecha revisión
	salida = ['A', infoarchivo[7], vol, ruta, nombre, infoarchivo[3], 
			'', '', tam, infoarchivo[4], infoarchivo[5], faudit, infoarchivo[6]]
	return salida


def formato_directorio(infoarchivo, vol, libre, faudit, tipo):
	if libre != 0:		# es el primer directoiro, formateamos como unidad
		tip = 'U'
		if libre < 1024*1024:
			lib = '%.2f' % (libre/(1024)) + ' KB.'
		elif libre < 1024*1024*1024:
			lib = '%.2f' % (libre/(1024*1024)) + ' MB.'
		else:
			lib = '%.2f' % (libre/(1024*1024*1024)) + ' GB.'
	else:
		tip = 'D'
		lib = ''
	
	# Info directorio: path, fechamod, numfiles, numdir, tamano, error
	ruta, err = c.mapeo_string(infoarchivo[1])
	if infoarchivo[6] == '' and err != '':
		infoarchivo[6] = err
	
	if infoarchivo[5] < 1024:
		tam = str(infoarchivo[5]) + ' Bytes'
	elif infoarchivo[5] < 1024*1024:
		tam = '%.2f' % (infoarchivo[5]/(1024)) + ' KB.'
	elif infoarchivo[5] < 1024*1024*1024:
		tam = '%.2f' % (infoarchivo[5]/(1024*1024)) + ' MB.'
	else:
		tam = '%.2f' % (infoarchivo[5]/(1024*1024*1024)) + ' GB.'
	nivelDir = '%.2d' % infoarchivo[7]
	
	if tipo == 'T':
		# Formato salida: ['D', nivel dir, volumen, directorio, vacío, fecha modificación,  
		# 		num. ficheros, num. directorios, tamaño formateado, tamaño, tipo archivo y fecha revisión
		salida = [tip, nivelDir, vol, ruta, '', infoarchivo[2], 
				infoarchivo[3], infoarchivo[4], tam, infoarchivo[5], lib, faudit, infoarchivo[6], libre]
	elif tipo == 'D':
		# Formato salida: [f. analisis, volumen, directorio, tamaño, fecha modificación,  
		# 		num. ficheros, num. directorios, espacio libre, error
		salida = [faudit, vol, ruta, infoarchivo[5], infoarchivo[2], 
				infoarchivo[3], infoarchivo[4], nivelDir, infoarchivo[6]]
	else:
		# Formato salida: [f. analisis, volumen, directorio, tamaño, fecha modificación,  
		# 		num. ficheros, num. directorios, espacio libre, error
		salida = [faudit, vol, ruta, infoarchivo[5], infoarchivo[2], 
				infoarchivo[3], infoarchivo[4], libre, infoarchivo[6]]
	return salida
