#  Proyecto ESPACIO Analizador de unidades (unidades, carpetas, usbs)
#  ====================================================================
#  Módulo general para funciones del proyecto
import os, time, string


dicbyte = { b'\x81' : b'u',  b'\xa6' : b'a', b'\xad' : b'!',	  # caractéres no válidos
			b'\xcc\x81' : b' ',   								  # caractéres no válidos
			b'\xcc\x83' : b' ', b'\xe2\x80\x8b' : b' ',           # caractéres no válidos
			b'\xc4\x97' : b'e',                                   # caractéres no válidos
			b'\u2705' : b' ',
			b'\xa0' : b'\xe1',	 # á
			b'\x82' : b'\xe9',	 # é
			b'\xa1' : b'\xed',	 # í
			b'\xa2' : b'\xf3',	 # ó
			b'\xa3' : b'\xfa', 	 # ú
			b'\xa4' : b'\xf1' 	 # ñ
			}



#  Devuelve el abcdario en mayúsculas
def Abcdario():
	return string.ascii_uppercase


#  Se formatea una fecha, en formato time, a string DD/MM/AAAA
def Fecha_ddmmaaaa(fecha):
	return time.strftime("%d/%m/%Y", fecha)


#  Obtener fecha y hora actual local
def Obtener_fecha():
	return time.localtime()

#  Obtener hora actual
def Obtener_hora():
	return time.time()

#  Convertir en fecha local
def Convertir_fechalocal(fecha_hora):
	return time.localtime(fecha_hora)



#  Se realiza la lectura del fichero byte a byte, "transformando" caracteres "extraños"
def Leerlinea(file):
	linea, byte = '', b' '
	byte = file.read(1)
	while byte != b'' and byte != b'\r':
		if byte in dicbyte:
			# caracter transformado que da error o es invalido
			byte = dicbyte[byte]
		try:
			linea += byte.decode(u'cp1252')
		except:
			print(f"Error al decodificar caracter: {byte}")
		
		byte = file.read(1)
	#print (' > ', linea)
	return linea



#  Se mapea una cadena string para "transformar" tíldes (codificando y decodificando)
def Mapeo_string(palabra):
	salida, error = '', ''
	for caracter in palabra:
		byte = caracter.encode('utf-8')
		if byte in dicbyte:
			# caracter transformado que da error o es invalido
			# print (byte, '>', dicbyte[byte])
			byte = dicbyte[byte]
			error = '(cambiado)'
		# print (byte, '>')
		salida += byte.decode('utf-8')	
	return salida, error



#  Ejecutar comando DOS usando el sistema
def Ejecutar_DOS(comando):
	os.system(comando)

#  Ejecución comando DOS usando OS.POPEN
def Ejecutar_DOS_popen(comando):
	return os.popen(comando)

#  Existe ruta
def Existe_ruta(ruta):
	return os.path.exists(ruta)

#  Comprobar si es directorio
def Es_directorio(ruta):
	return os.path.isdir(ruta)

#  Leer los directorios
def Leer_directorios(ruta):
	return os.listdir(ruta)

#  Crear ruta + fichero
def Crear_ruta(ruta, fichero):
	return os.path.join(ruta, fichero)

#  Separar fichero: nombre + extensión
def Separar_nombre_extension(fichero):
	return os.path.splitext(fichero)

#  Obtener información de fichero, formato OS.STAT(fichero)
def Obtener_información_ficchero(fichero):
	return os.stat(fichero)



#  Cambiar nombre a algunas unidades
def Cambiar_nombre_unidad(nombre):
	dic_unidades = {'USB_PELICULAS'	: 'VIDEOTECA',
					'VIDEO'			: 'NAS VIDEO',
					'HOMES'			: 'NAS HOMES',
					'BACKUP'		: 'NAS BACKUP',
					'PHOTO'			: 'NAS PHOTO',
					'MUSIC'			: 'NAS MUSIC'}
	if nombre.upper() in dic_unidades:
		salida = dic_unidades[nombre.upper()]
	else:
		salida = nombre.upper()
	return salida




if __name__ == "__main__":
	acento = u"\u0301"  # tilde
	e = u'\u0117' 		# ė
	u = u'\u200b'      
	texto = 'España á,é,í,ó,ú Yagüe ' + acento + 'a' + e + u

	Mapeo_string(texto)
