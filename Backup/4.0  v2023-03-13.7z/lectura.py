#  Proyecto ESPACIO - Analizador de unidades (unidades, carpetas, usbs)
#  ====================================================================
# import sys
# from stat import *

#  Importamos módulo general de funciones del proyecto
from funciones import *


tipos = {'.py':'Python', '.pyc':'Python', '.txt':'texto', 
		'.jpg':'foto', '.mp4':'video', 
		'.doc':'documento','.docx':'documento',
		'.xls':'Excel', '.xlsx':'Excel', '.csv':'Excel', 
		'.ppt':'presentacion', '.pptx':'presentacion', 
		'.pdf':'pdf', 
		'':'vacio',
		'.exe':'ejecutable', 
		'.sqlite':'BD Sqlite', '.sqlite3':'BD Sqlite', '.db':'BD Sqlite', '.db3':'BD Sqlite'} 

sintipo = []

tmp = u'dirtmp'
ext = u'.txt'


def Leer_unidad(ruta):
	#  Se lee la unidad usando el comando DOS DIR de la ruta dada (se usa os.popen)
	ftmp = tmp + ruta[0] + ext
	comando = 'dir ' + ruta + ' > ' + ftmp
	f = Ejecutar_DOS_popen(comando)
	f.close()

	with open(ftmp, 'rb') as f:
		#  Las dos primeras líneas contienes el volumen y el número de serie (clave de unidades)
		#   - Se usa función cambiar nombres para renombrar algunas unidades leídas
		volumen = Cambiar_nombre_unidad(Leerlinea(f)[30:])
		libre = 0
		fechaudit = Obtener_fecha()

		while True:
			linea = Leerlinea(f)
			
			if linea == '':
				break	# Hemos llegado al final del fichero y salimos del bucle
			
			elif linea.find('dirs') != -1:
				libre = int(linea[23:linea.find('bytes')].replace(" ","").replace(".",""))
	
	# Borramos el fichero temporal
	comando = 'del ' + ftmp
	Ejecutar_DOS(comando)
	
	return volumen, libre, fechaudit



def Leer_ruta(ruta):
	files, subdir, error, file = [], [], '', ''
	try:
		listdirs = []
		listdirs = Leer_directorios(ruta)
	except PermissionError:
		#print ('ruta: ', ruta, ' Acceso denegado')
		error = ' (Acceso Denegado)'		
		return files, subdir, error
	
	for file in listdirs:
		try:
			pathname = Crear_ruta(ruta, file)
			if Es_directorio(pathname):		# Tratamiento de subdirectorios
				subdir.append(pathname)
			else:							# Tratamiento de archivos
				files.append(file)
		except:
			print ('ruta: ', ruta, ' file: ', file, ' Error en ISDIR o ISFILE')
			error = ' (Error ISDIR o ISFILE)'		
			return files, subdir, error

	return files, subdir, error





def Leer_file(ruta, archivo):
	nombre, extension = Separar_nombre_extension(archivo)
	nombre_completo = Crear_ruta(ruta, archivo)
	
	error, tipo = '', ''
	if extension.lower() in tipos:
		tipo = tipos[extension.lower()]
	elif not extension.lower() in sintipo:
		sintipo.append(extension.lower())

	try:
		tamano, fechamod = 0, ''
		e = Obtener_información_ficchero(nombre_completo)
		tamano = e.st_size
		fechamod = Convertir_fechalocal(e.st_mtime)
	except PermissionError:
		#print ('file: ', nombre_completo, ' Acceso denegado')
		error = ' (Acceso Denegado)'
	except FileNotFoundError:
		#print ('file: ', nombre_completo, ' Fichero no encontrado')
		error = ' (No encontrado)'
	
	return nombre, extension, tipo, fechamod, tamano, error



	
if __name__ == "__main__":
	pass
