#  Proyecto ESPACIO - Analizador de unidades (unidades, carpetas, usbs)
#  =====================================================================

# Módulos del proyecto
from funciones import *
import discos   as d		# Módulo de mantenimiento de Unidades/Directorios/Ficheros




def menu():
	print ('''
	1. Leer todas las unidades
	2. Leer unidad
	3. Listar unidades en memoria
	
	8. Leer fichero CSV
	9. Exportar a CSV Unidades
	0. Salir
		''')
	try:
		opcion = int(input('Introduzca opción: '))
	except:
		opcion = 9999
		print ('\n', 'Por favor introduzca un valor numérico.')
	return opcion



def valorar_opcion(opcion):
	#  Limpiar pantalla, ejecutamos comando DOS cls
	comando = 'cls'
	Ejecutar_DOS(comando)
	
	if opcion == 1:
		unidades.Leer_todos()

	if opcion == 2: 
		ruta = input ('Introduzca ruta: ')
		# Analizar la información de la ruta introducida por parámetro (unidad, directorios y ficheros)
		unidades.Leer_disco(ruta)

	elif opcion == 3:
		# Listar las unidades almacenadas en memoria
		unidades.Listar_unidades()

	elif opcion == 8:
		# Leer unidades del fichero .CSV
		unidades.Leer_csv()

	elif opcion == 9:
		# Exportamos la información de unidades a fichero CSV
		opcion = 9999
		while opcion != 0:
			opcion = submenu_exportar()
			valorar_exportar(opcion)
		
		opcion = 9999
	elif opcion == 0:
		print("\n Adios....") 



def submenu_exportar():
	print ('''
	1. Unidades
	2. Directorios
	3. Todo
	0. Salir
		''')
	try:
		opcion = int(input('Introduzca opción: '))
	except:
		opcion = 9999
		print ('\n', 'Por favor introduzca un valor numérico.')
	return opcion



def valorar_exportar(opcion):
	if opcion == 1: 
		# Exportamos a fichero CSV solo las unidades
		unidades.Exportar_csv('U')

	elif opcion == 2:
		max_nivel = int(input ('Introduzca nivel máximo de subdirectorios: '))
		# Exportamos a fichero CSV las unidades y directorios (niveles 0 y 1 por defecto)
		unidades.Exportar_csv('D', max_nivel)

	elif opcion == 3:
		# Exportamos TODA la información de unidades a fichero CSV
		unidades.Exportar_csv('T')
	
	elif opcion == 0:
		print("\n Adios....") 



if __name__ == "__main__":
	opcion = 9999
	unidades = d.Discos()
	
	while opcion != 0:
		opcion = menu()
		valorar_opcion(opcion)
	
	# Borramos la variable Unidad
	del unidades
