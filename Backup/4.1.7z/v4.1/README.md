Repositorio Proyecto ESPACIO (Python)
=====================================

   Actualizaciones, nuevas funcionalidades
   ---------------------------------------

     - Tiempo a exportar CSV ->  dejar dos decimales y poner "seg.".
     - Opción en el menú de borrar datos leídos (discos leídos).   
     - Incorporar columna "Backup", calculada en base a si el nombre del directorio contiene
     palabras de tabla "Estructura directorios (Bitácora discos)", información nivel 1, 2 y 3.
     - Leer clasificación = "Estructura directorios" de tabla/hoja excel
     - Crear hoja excel directamente o hoja google sheets
     - Desde Python, crearla en google.
        * Antes hay que ver si existe y borrarla para meterla
        * Ser capaz de leerla, etc.
