#  Proyecto ESPACIO - Analizador de unidades (unidades, carpetas, usbs)
#  ====================================================================
#  Importamos libreria openpyxl para manejar ficheros excel
import openpyxl
#  Importamos librería pandas
import pandas as pd

#  Importamos módulo general de funciones del proyecto
from funciones import *
from informe import *


fichero = u'Bitácora Discos.xlsx'
Informe = u'Informe'
Unidades = u'Discos'
Directorios = u'Directorios'
Backup = u'Backup'


class FileExcel():
	def __init__(self, modo, tipo='T'):
		#  Definimos/abrimos libro excel
		self.libro = openpyxl.load_workbook(fichero)
		self.modo = modo
		if modo == 'a':
			print(" -> No implementada pestaña backup")
		if tipo == 'U':
			self.pestaña = self.libro[Unidades]
		elif tipo == 'D':
			self.pestaña = self.libro[Directorios]
		else:
			self.pestaña = self.libro[Informe]
		
		#  Actuamos como si sobreescribieramos la pestaña, borramos lo que hay
		# self.pestaña.delete_rows(1, self.pestaña.max_row)
		
		if modo == 'w' or modo == 'a':
			self.pestaña.append(Formato_cabecera(tipo))
		else:
			#  Lectura del excel 
			self.contador = 0

			
	def Leer_registro(self):
		try:
			self.contador += 1
			return [self.pestaña.cell(row= self.contador, column=i).value 
						for i in range(1, self.pestaña.max_column + 1)]
		except:
			return ''


	def Escribir_registro(self, registro):
		self.pestaña.append(registro)


	def Grabar_CSV(self, lista, tipo):
		# Formateamos la salida dependiendo si es información de Unidad, Directorio o Archivo
		for reg in lista:
			if reg[0] == 'U':	   # Contiene info unidad.: volumen, espacio_libre, fecha uditoria
				vol, err = Mapeo_string(reg[1])
				libre = reg[2]
				faudit = reg[3]
			elif reg[0] == 'D':	   # contiene info dir....: path, fechamod, numfiles, numdir, tamano, error, nivel
				if tipo == 'T' or (libre != 0 and tipo == 'U') or (libre == 0 and tipo == 'D' and reg[6] != ' (Acceso Denegado)'):
					self.Escribir_registro(Formato_directorio(reg, vol, libre, faudit, tipo))
				
				ruta, err = Mapeo_string(reg[1])
				libre = 0
			elif reg[0] == 'A':	   # contiene info archivo:  nombre, extension, fechamod, tamano, tipo, error, nivel
				self.Escribir_registro(Formato_archivo(reg, vol, faudit, ruta))
			else:
				print ('Info de unidad errónea al formatear salida a csv.')



	def __del__(self):
		#  Grabar la información si modo es escritura (w o a) 
		if self.modo == 'w' or self.modo == 'a':
			self.libro.save(fichero)
				
