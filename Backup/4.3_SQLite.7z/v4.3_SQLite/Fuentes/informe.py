#  Proyecto ESPACIO - Analizador de unidades (unidades, carpetas, usbs)
#  ====================================================================
#  Módulo de formateo de informes


#  Importamos módulo general de funciones del proyecto
from funciones import *



def Formato_cabecera(tipo):
	#  Generamos la cabecera para Unidades, Directorios o Todo
	if tipo == 'T':
		cabecera = ('Tipo', 'Nivel Dir', 'Disco', 'Directorio', 'Nombre', 'Fecha Mod.', 'Ficheros',
					'Directorios', 'Tamaño', 'Bytes', 'Libre', 'Fecha', 'Error')
	elif tipo == 'D':
		cabecera = ('Fecha', 'Niv', 'Disco', 'Directorio', 'Tamaño', 'Gb.', 'Fecha Mod.', 
					'Fich.', 'Dir.', 'Backup')
	else:
		cabecera = ('Fecha', 'Disco', 'Tamaño', 'Gb.', 'Fecha Mod.', 'Ficheros', 'Directorios', 'Libre', 'Gb. Libre')
	return cabecera



def Info_unidad(reg):
	# Clase Unidad: volumen, espacio_libre, fechaudit
	return reg[2], int(reg[13]), reg[11]
	
def Info_directorio(reg):
	# Clase Directorio: path, fechamod, numfiles, numdir, tamano, error
	return reg[3], reg[5], int(reg[6]), int(reg[7]), int(reg[9]), reg[12]

def Info_fichero(reg):
	nombre, extension = os.path.splitext(reg[4])
	# Clase Fichero: nombre, extension, tipo, fechamod, tamano, error
	return nombre, extension, reg[10], reg[5], int(reg[9]), reg[12]



def Formato_archivo(infoarchivo, vol, faudit, ruta):
	# Info archivo: nombre, extension, fechamod, tamano, tipo, error, nivel
	nombre, err = Mapeo_string(infoarchivo[1]+infoarchivo[2])
	if infoarchivo[6] == '' and err != '':
		infoarchivo[6] = err

	if infoarchivo[4] < 1024*1024*1024:
		tam = str(infoarchivo[4])
	else:
		tam = '%.2f' % (infoarchivo[4]/(1024*1024*1024)) + ' GB.'
	
	fecha = Fecha_ddmmaaaa(faudit)
	if infoarchivo[3] != '':
		fechamod = Fecha_ddmmaaaa(infoarchivo[3])
	else:
		fechamod = ''
	# Formato salida: ['U', nivel dir., volumen, directorio, nombre completo, fecha modificación,  
	# 		num. ficheros y dir. vacío, tamaño formateado, tamaño, tipo archivo y fecha revisión
	salida = ['A', infoarchivo[7], vol, ruta, nombre, fechamod, 
			'', '', tam, infoarchivo[4], infoarchivo[5], fecha, infoarchivo[6]]
	return salida


def Formato_directorio(infoarchivo, vol, libre, faudit, tipo):
	if libre != 0:		# es el primer directoiro, formateamos como unidad
		tip = 'U'
	else:
		tip = 'D'
	
	# Info directorio: path, fechamod, numfiles, numdir, tamano, error
	ruta, err = Mapeo_string(infoarchivo[1])
	if infoarchivo[6] == '' and err != '':
		infoarchivo[6] = err
	
	tam_Gb = infoarchivo[5]/(1024*1024*1024)
	libre_Gb = libre/(1024*1024*1024)
	nivelDir = '%.2d' % infoarchivo[7]
	
	fecha = Fecha_ddmmaaaa(faudit)
	if infoarchivo[2] != '':
		fechamod = Fecha_ddmmaaaa(infoarchivo[2])
	else:
		fechamod = ''

	if tipo == 'T':
		# Formato salida: ['D', nivel dir, volumen, directorio, vacío, fecha modificación,  
		# 		num. ficheros, num. directorios, tamaño formateado, tamaño, tipo archivo y fecha revisión
		salida = [tip, nivelDir, vol, ruta, '', fechamod, 
				infoarchivo[3], infoarchivo[4], tam_Gb, infoarchivo[5], libre_Gb, fecha, infoarchivo[6], libre]
	elif tipo == 'D':
		# Formato salida: [f. analisis, volumen, directorio, tamaño, fecha modificación,  
		# 		num. ficheros, num. directorios, espacio libre, error
		salida = [fecha, nivelDir, vol, ruta, infoarchivo[5], tam_Gb, fechamod, 
				infoarchivo[3], infoarchivo[4], infoarchivo[6]]
	else:
		# Formato salida: [f. analisis, volumen, tamaño, tamaño en Gb, fecha modificación,  
		# 		num. ficheros, num. directorios, espacio libre, libre en Gb.
		salida = [fecha, vol, infoarchivo[5], tam_Gb, fechamod, 
				infoarchivo[3], infoarchivo[4], libre, libre_Gb]
	return salida
