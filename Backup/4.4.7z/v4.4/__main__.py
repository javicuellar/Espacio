#  Proyecto ESPACIO v5.2 - Analizador de Dispositivo (unidades, directorios y ficheros)
#  ====================================================================================
from lectura import *




ficheroBD = u'almacen.db'


if __name__ == "__main__":
	disp = Dispositivo(ficheroBD)
	disp.GrabarDispositivo()
	
	# Borramos la variables
	del disp
