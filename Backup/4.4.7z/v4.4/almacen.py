#  Lectura de dispositivo: unidades, directorios y ficheros
#  ========================================================
from threading import Thread
import platform, os, sys

# Módulos del proyecto
from funciones import *
# import lectura as l			# Módulo de lectura de información de la Unidad, extrae sus directorios y ficheros
from grabacion import *



# -------------------------------------------------------------------------------------------------------------------------
#  Información del SISTEMA sobre el que se está ejecutando -> nombre, sistema, so, maquina, arquitectura, procesador, fecha
class Dispositivo():
	def __init__(self):
		self.equipo = getattr(platform, 'node')()
		self.sistema = getattr(platform, 'system')()
		self.so = getattr(platform, 'platform')()
		self.maquina = getattr(platform, 'machine')()
		self.arquitectura = getattr(platform, 'architecture')()[0]
		self.procesador = getattr(platform, 'processor')()
		self.fecha = Obtener_fecha()
		self.discos = Unidades(self.equipo, self.fecha)
	

	def Exportar(self):
		return [[self.equipo, self.sistema, self.so, self.maquina, self.arquitectura, self.procesador, self.fecha]]
	
	
	def GrabarDispositivo(self):
		bd = BaseDatos()
		bd.GrabarDispositivos(self.Exportar())
		bd.GrabarUnidades(self.discos.unidades)
		bd.GrabarDirectorios(self.discos.directorios)
		bd.GrabarFicheros(self.discos.ficheros)
		del bd



# -------------------------------------------------------------------------------------------------------------------------
#  Información de las UNIDADES conectadas
class Unidades():
	def __init__(self, equipo, fecha):
		self.equipo = equipo
		self.fecha = fecha
		self.unidades = []
		self.directorios = []
		self.ficheros = []

		hilos = []
		for i in Abcdario():
			ruta = i + ':\\'
			if Existe_ruta(ruta):
				print("> Analizando unidad: ", ruta)
				hilo = Thread(target=self.Leer_Unidad, args=(ruta, ))
				hilo.start()
				hilos.append(hilo)
		for i in hilos:
			i.join()


	#   Información de la UNIDAD -> equipo, num. serie, volumen, libre, fecha
	def Leer_Unidad(self, ruta):
		tiempo_ini = Obtener_hora()
		
		f = os.popen('dir ' + ruta)
		volumen = Cambiar_nombre_unidad(f.readline()[30:-1])
		numserie = f.readline()[36:-1]
		libre = 0
		while True:
			linea = f.readline()
			if linea == '':             # Hemos llegado al final del fichero y salimos del bucle
				break
			elif linea.find('dirs') != -1:
				libre = int(linea[23:linea.find('bytes')].replace(" ","").replace(".",""))	
		f.close()
		
		self.Leer_Directorio(numserie, ruta, '')

		seg = int(Obtener_hora() - tiempo_ini)
		tiempo = 'Tiempo lectura ' + ruta + '  ' + str(seg // 60) + "'" + str(seg % 60) + '"'
		print ('\n', tiempo)
		self.unidades.append([self.equipo, numserie , volumen, libre, self.fecha, tiempo])


	#   Información del DIRECTORIO -> num. serie, ruta, fecha
	def Leer_Directorio(self, numserie, ruta, error):
		try:
			elementos = os.listdir(ruta)
		except PermissionError:
			# print('> dir: ', ruta, ' Acceso denegado1')
			error = 'Acceso Denegado1'
			elementos = []
		except Exception as error:
			print('> dir: ', ruta, ' Error: ', error)
			elementos = []

		self.directorios.append([numserie, ruta, error, self.fecha])

		for elemento in elementos:
			path = os.path.join(ruta, elemento)
			
			try:
				evalua = os.path.isdir(path)
			except PermissionError:
				print ('> elemento: ', path, ' Acceso denegado2')
				error = 'Acceso Denegado2'
				self.directorios.append([numserie, path, error, self.fecha])
			except Exception as error:
				print ('> elemento: ', ruta, " -> ", elemento, " Error: ", error)
				self.Leer_Fichero(numserie, ruta, elemento, error)
			else:
				if evalua:
					self.Leer_Directorio(numserie, path, '')
				else:
					self.Leer_Fichero(numserie, ruta, elemento, '')



	#  Información del FICHERO -> numserie, ruta, nombre, extension, tipo, fechamod, tamaño, error, fecha
	def Leer_Fichero(self, numserie, ruta, fichero, error):
		nombre, extension = os.path.splitext(fichero)
		if extension.lower() in tipos:
			tipo = tipos[extension.lower()]
		elif not extension.lower() in sintipo:
			tipo = ''
			sintipo.append(extension.lower())
		else:
			tipo = ''
		
		if error != '':
			print(">--> llegan errores: ", error, " nombre y extesion: ", nombre, extension)
			self.ficheros.append([numserie, ruta, nombre, extension, tipo, '0000-00-00', 0, error, self.fecha])
		else:
			try:
				info_fichero = os.stat(os.path.join(ruta, fichero))
			except PermissionError:
				print ('> fichero: ', os.path.join(ruta, fichero), ' Acceso denegado3')
				error = 'Acceso Denegado3'
			except FileNotFoundError:
				# > ACCESO DIRECTO.- es un fichero que está en el directorio pero no permite acceder.
				# print ('> fichero: ', os.path.join(ruta, fichero), ' Fichero no encontrado')
				error = 'Acceso directo'
			except Exception as error:
				print ('> fichero: ', os.path.join(ruta, fichero), ' Error: ', error)
			else:
				tamaño = info_fichero.st_size
				fechamod = datetime.fromtimestamp(info_fichero.st_mtime, tz=timezone.utc)
				self.ficheros.append([numserie, ruta, nombre, extension, tipo, fechamod, tamaño, error, self.fecha])
			finally:
				self.ficheros.append([numserie, ruta, nombre, extension, tipo,  '0000-00-00', 0, error, self.fecha])



sintipo =[]


if __name__ == "__main__":
	#  Pruebas módulo
	print("\n")
	disp = Dispositivo()
	disp.GrabarDispositivo()
	
	# Borramos la variables
	del disp
