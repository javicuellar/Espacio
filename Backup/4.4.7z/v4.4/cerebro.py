#  Cerebro del proyecto. Aquí es donde se debe:
#
#   1) leer la información de BD
#   2) Analizar la información.- búsqueda patrones (etiquetas), duplicados, basura (a borrar), etc.
#   3) Informe.- sacar informes excel para su "preanálisis"
#   4) Actualizar información BD
#       * Comparar.- nuevos, modificados y eliminados (almacenar cambios, cómo ??)

from grabacion import *
import pandas as pd


#  eliminar después, está en __main__
ficheroBD = 'D:\\Python\\Espacio\\almacen.db'


def Leer_BD():
    bd = BaseDatos(ficheroBD)

    dispositivos = bd.Leerdispositivos()
    unidades = bd.Leerunidades()
    directorios = bd.Leerdirectorios('0C5E-B9FC')
    ficheros = bd.Leerficheros('0C5E-B9FC')
    print("Dispositivos\n", dispositivos)
    print("Unidades\n", unidades)
    print("Directorios:\n", directorios)
    print("Ficheros\n", ficheros)
    
    del bd
    return dispositivos, unidades, directorios, ficheros



def Grabar_cambios():
    # Selecciona sólo datos que volumen contenga CLOUD
    volumenCLOUD = df[df.volumen.str.contains('CLOUD')]
    # planets[planets.method.str.contains('pulsa')]

    # Escribe los datos del nuevo DataFrame en una nueva tabla en SQLite
    volumenCLOUD.to_sql("unidadesCloud", bd, if_exists="replace")



# --------------------------------------------------------------------------------------------
dispositivos, unidades, directorios, ficheros = Leer_BD()

# dirAgrup = df[df['Abierta'] == 'A']
dirAgrup = ficheros.groupby(['ruta']).sum()
#dfActivos.reset_index(inplace=True)
print(dirAgrup)
