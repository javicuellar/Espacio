#  Módulo general para funciones del proyecto

# -------------------------------------------------------------------------------------------------------------------------
import string

#  Devuelve el abcdario en mayúsculas
def Abcdario():
	return string.ascii_uppercase


# -------------------------------------------------------------------------------------------------------------------------
import time
from datetime import datetime, timezone

#  Se formatea una fecha, en formato time, a string DD/MM/AAAA
def Fecha_ddmmaaaa(fecha):
	return time.strftime("%d/%m/%Y", fecha)

#  Obtener fecha y hora actual local
def Obtener_fecha():
	#return time.localtime()
	return datetime.now()

#  Obtener hora actual
def Obtener_hora():
	return time.time()

#  Convertir en fecha local
def Convertir_fechalocal(fecha_hora):
	#return time.localtime(fecha_hora)
	return datetime.fromtimestamp(fecha_hora, tz=timezone.utc)



# -------------------------------------------------------------------------------------------------------------------------
import os

#  Ejecutar comando DOS usando el sistema
def Ejecutar_DOS(comando):
	os.system(comando)

#  Ejecución comando DOS usando OS.POPEN
def Ejecutar_DOS_popen(comando):
	return os.popen(comando)

#  Existe ruta
def Existe_ruta(ruta):
	return os.path.exists(ruta)

#  Comprobar si es directorio
def Es_directorio(ruta):
	return os.path.isdir(ruta)

#  Leer los directorios
def Leer_directorios(ruta):
	return os.listdir(ruta)

#  Crear ruta + fichero
def Crear_ruta(ruta, fichero):
	return os.path.join(ruta, fichero)

#  Separar fichero: nombre + extensión
def Separar_nombre_extension(fichero):
	return os.path.splitext(fichero)

#  Obtener información de fichero, formato OS.STAT(fichero)
def Obtener_información_fichero(fichero):
	return os.stat(fichero)




# -------------------------------------------------------------------------------------------------------------------------
dicbyte = { b'\x81' : b'u',  b'\xa6' : b'a', b'\xad' : b'!',	  # caractéres no válidos
			b'\xcc\x81' : b' ',   								  # caractéres no válidos
			b'\xcc\x83' : b' ', b'\xe2\x80\x8b' : b' ',           # caractéres no válidos
			b'\xc4\x97' : b'e',                                   # caractéres no válidos
			b'\u2705' : b' ',
			b'\xa0' : b'\xe1',	 # á
			b'\x82' : b'\xe9',	 # é
			b'\xa1' : b'\xed',	 # í
			b'\xa2' : b'\xf3',	 # ó
			b'\xa3' : b'\xfa', 	 # ú
			b'\xa4' : b'\xf1' 	 # ñ
			}

#  Se realiza la lectura del fichero byte a byte, "transformando" caracteres "extraños"
def Leerlinea(file):
	linea, byte = '', b' '
	byte = file.read(1)
	print(" > byte: ", byte)
	while byte != b'' and byte != b'\r':
		print(" > byte: ", byte)
		if byte in dicbyte:
			# caracter transformado que da error o es invalido
			byte = dicbyte[byte]
		try:
			linea += byte.decode(u'cp1252')
		except:
			print(f"Error al decodificar caracter: {byte}")
			break
		
		byte = file.read(1)
	print (' > ', linea)
	return linea



#  Se mapea una cadena string para "transformar" tíldes (codificando y decodificando)
def Mapeo_string(palabra):
	salida, error = '', ''
	for caracter in palabra:
		byte = caracter.encode('utf-8')
		if byte in dicbyte:
			# caracter transformado que da error o es invalido
			# print (byte, '>', dicbyte[byte])
			byte = dicbyte[byte]
			error = '(cambiado)'
		# print (byte, '>')
		salida += byte.decode('utf-8')	
	return salida, error

#  Cambiar nombre a algunas unidades
def Cambiar_nombre_unidad(nombre):
	dic_unidades = {'USB_PELICULAS'	: 'VIDEOTECA',
					'VIDEO'			: 'NAS VIDEO',
					'HOMES'			: 'NAS HOMES',
					'BACKUP'		: 'NAS BACKUP',
					'PHOTO'			: 'NAS PHOTO',
					'MUSIC'			: 'NAS MUSIC'}
	if nombre.upper() in dic_unidades:
		salida = dic_unidades[nombre.upper()]
	else:
		salida = nombre.upper()
	return salida





# -------------------------------------------------------------------------------------------------------------------------
import psutil

#  Información de la CPU
def Información_CPU():
	nucleos_fisicos = psutil.cpu_count(logical=False)
	nucleos_total = psutil.cpu_count(logical=True)
	cpu_frecuencia = psutil.cpu_freq()
	for i, porc in enumerate(psutil.cpu_percent(percpu=True)):
		print(f"Core {i}: {porc}%")
	print("Total uso CPU: ", psutil.cpu_percent(), "%")
	return (nucleos_fisicos, nucleos_total, cpu_frecuencia.max, cpu_frecuencia.min, cpu_frecuencia.current)


def get_size(bytes, suffix="B"):
	factor = 1024
	for unit in ["", "K", "M", "G", "I", "P"]:
		if bytes < factor:
			return f"{bytes:.2f} {unit}{suffix}"
		bytes /= factor

def Información_Memoria():
	mem = psutil.virtual_memory()
	print(mem)
	mem_total = get_size(mem.total)
	mem_disponible = get_size(mem.available)
	mem_usada = get_size(mem.used)
	mem_libre = get_size(mem.free)
	mem_porc = mem.percent

	swap = psutil.swap_memory()
	print(swap)
	swap_total = get_size(swap.total)
	swap_usada = get_size(swap.used)
	swap_libre = get_size(swap.free)
	swap_porc = swap.percent
	return (mem_total, mem_disponible, mem_usada, mem_porc, swap_total, swap_usada, swap_libre, swap_porc)


def Información_Disco():
	print("\nInformación Disco")
	particiones = psutil.disk_partitions()
	for partición in particiones:
		print("  Montada: ", partición.mountpoint, " Tipo: ", partición.fstype)
		try:
			print("    > ", psutil.disk_usage(partición.mountpoint))
		except Exception as error:
			print("    > error: ", error)
	print("\nIO Contadores: ", psutil.disk_io_counters())



#  ------------------------------------------------------------------------------------------------------------------------
tipos = {'.py':'Python', '.pyc':'Python', '.txt':'texto', 
		'.jpg':'foto', '.mp4':'video', 
		'.doc':'documento','.docx':'documento',
		'.xls':'Excel', '.xlsx':'Excel', '.csv':'Excel', 
		'.ppt':'presentacion', '.pptx':'presentacion', 
		'.pdf':'pdf', 
		'':'vacio',
		'.exe':'ejecutable', 
		'.sqlite':'BD Sqlite', '.sqlite3':'BD Sqlite', '.db':'BD Sqlite', '.db3':'BD Sqlite'} 

sintipo = []
#  ------------------------------------------------------------------------------------------------------------------------



if __name__ == "__main__":
	acento = u"\u0301"  # tilde
	e = u'\u0117' 		# ė
	u = u'\u200b'      
	texto = 'España á,é,í,ó,ú Yagüe ' + acento + 'a' + e + u

	Mapeo_string(texto)

	print(Información_CPU())
	print(Información_Memoria())
	Información_Disco()
