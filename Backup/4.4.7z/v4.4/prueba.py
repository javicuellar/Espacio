# para buscar una lista en otra, quizas me sirma para buscar ficheros en ficheros.
import time

valores = range(40000)
datos = range(0, 10000, 3)

i = time.time()
True in [v in datos for v in valores]
time_option1 = time.time() - i

i = time.time()
any(v in datos for v in valores)
time_option2 = time.time() - i

print (time_option1)
print (time_option2)

#  segundos, dividir y calcular min. segundos
seg = 75
print('Minutos: ', seg // 60, "'", seg % 60, "''")


