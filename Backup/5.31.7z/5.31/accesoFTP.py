from ftplib import FTP, all_errors




#   Conexión FTP al Servidor
def ConexiónFTP(config):
    ftp = 'FTP'
    servidor = config['Servidor']['servidor']
    usuario = config[ftp]['usuario']
    password = config[ftp]['password']

    try:
        ftpEspacio = FTP()
        ftpEspacio.connect(servidor)
        ftpEspacio.login(usuario, password)
        return ftpEspacio

    except all_errors as e:
        print(f'Error FTP: {e}')



#   Configuramos conexión FTP y descargar ficheros de la aplicación (directorio app)
def DescargarFTP(config, app, version, modulo):
    ftp = ConexiónFTP(config)

    try:
        ftp.cwd(app)
        ficheros = []
        ftp.dir(ficheros.append)
        for f in ficheros:
            tipo = f[0]
            directorio = f[59:]
            if tipo == 'd':     # Es un directorio
                break
        
        if modulo == 'Master':
            appDisplay = 'Actualizar'
        else:
            appDisplay = app
        
        if modulo == 'Instalar' or directorio > version:
            print("Script Actualizar - Versión", appDisplay, version, "-> Versión Servidor", directorio)
            ftp.cwd(directorio)
            ficheros = []
            ftp.dir(ficheros.append)
            for f in ficheros:
                fichero = f[59:]
                if (modulo == 'Actualizar' and fichero != 'Actualizar.exe')     \
                or (modulo == 'Master' and fichero == 'Actualizar.exe')         \
                or (modulo == 'Instalar'):
                    cmd = "RETR " + fichero
                    with open(fichero, "wb") as f:
                        ftp.retrbinary(cmd, f.write)
                #else:
                    #print("Fichero no descargado -> ", fichero, " - Módulo: ", modulo)
    except all_errors as e:
        print(f'Error FTP: {e}')
 
    del ftp



#   Configuramos conexión FTP y descargar fichero de BBDD de la app
def DescargarBBDD(config, app, bd):
    ftp = ConexiónFTP(config)

    try:
        ftp.cwd(app)
        cmd = "RETR " + bd
        with open(bd, "wb") as f:
            ftp.retrbinary(cmd, f.write)
        return True
    except all_errors as e:
        print(f'Error FTP: {e}')
        return False
 
    del ftp


#   Configuramos conexión FTP y descargar fichero de BBDD de la app
def SubirBBDD(config, app, bd):
    ftp = ConexiónFTP(config)

    try:
        ftp.cwd(app)
        cmd = "STOR " + bd
        with open(bd, 'rb') as f:
            ftp.storbinary(cmd, f)
    except all_errors as e:
        print(f'Error FTP: {e}')
 
    del ftp
