###################################################################################################################################
#  Proyecto: ESPACIO, Módulo GeneraExcel - Genera Excel con Unidades, Directorios y Ficheros
#  ==============================================================================================
app = 'Espacio'
#    Modulo Espacio - Versión inicial 0.0
#    ---------------------------------------
version = '0.33'
#       * Generar Excel a partir de la BD SqlLite, usando dataframes. 
###################################################################################################################################
import pandas as pd
import sqlite3, time, os
from datetime import datetime
from leerConfig import LeerConfig



print("Script GeneraExcel - Versión", version, "  ", datetime.now().strftime("%d/%m/%Y %H:%M"))

tiempo_ini = int(time.time())

#  Carga de diccionarios de Configuración
config = LeerConfig(app)

if config != {}:
    path = config['Ruta']['ruta'] + app
    os.chdir(path)

    bd = sqlite3.connect(config['Ruta']['Almacen'])
    sql = 'SELECT * FROM unidades'
    unidades = pd.read_sql_query(sql, bd)
    sql = 'SELECT * FROM directorios'
    directorios = pd.read_sql_query(sql, bd)
    sql = 'SELECT * FROM ficheros'
    ficheros = pd.read_sql_query(sql, bd)

    #  Modificamos los datos de la BD Unidades 
    #   - Añadimos columna Gb. de: total / usado / libre
    #   - Reordenamos las columnas
    #   - Formateamos la fecha
    unidades['Gb'] = unidades['total'].apply(lambda n: n / 1024**3)
    unidades['Gb.'] = unidades['usado'].apply(lambda n: n / 1024**3)
    unidades['Gb..'] = unidades['libre'].apply(lambda n: n / 1024**3)
    unidades = unidades.reindex(columns=['fecha', 'equipo', 'volumen', 'tipo', 'total', 'Gb', 'usado', 'Gb.', 'porcentaje', 
                                     'libre', 'Gb..', 'tiempo'])
    unidades['fecha'] = pd.to_datetime(unidades['fecha'], format="%Y-%m-%d %H:%M:%S").dt.strftime('%d-%m-%Y')

    #  Modificamos los datos de la BD Directorios 
    #   - Añadimos columna Dir con el nivel de directorio (contando el núm de veces que tiene '\' + 1)
    #   - Añadimos columna Gb. de tamaño
    #   - Reordenamos las columnas
    #   - Formateamos la fecha
    directorios['Niv'] = directorios['ruta'].apply(lambda n: n.count('\\') + 1)
    directorios['fecha'] = pd.to_datetime(directorios['fecha'], format="%Y-%m-%d %H:%M:%S").dt.strftime('%d-%m-%Y')
    directorios['Gb'] = directorios['tamaño'].apply(lambda n: n / 1024**3)
    directorios = directorios.reindex(columns=['fecha', 'equipo', 'volumen', 'Niv', 'ruta', 'tamaño', 'Gb', 'fechamod', 'numdir', 'numfich', 'error'])
    
    #  Contar las veces que aparece un fichero, lo primero es obtener el nombre del fichero juntando nombre y extension
    ficheros['fichero'] = ficheros['nombre'] + ficheros['extension']
    ficheros['contar'] = ficheros.groupby('fichero')['fichero'].transform('count')
    ficheros['fecha'] = pd.to_datetime(ficheros['fecha'], format="%Y-%m-%d %H:%M:%S").dt.strftime('%d-%m-%Y')
    ficheros['fechamod'] = pd.to_datetime(ficheros['fechamod'], format="%Y-%m-%d %H:%M:%S").dt.strftime('%d-%m-%Y %H:%M')
    ficheros['Gb'] = ficheros['tamaño'].apply(lambda n: n / 1024**3)
    del ficheros['fichero']
    ficheros = ficheros.reindex(columns=['fecha', 'equipo', 'volumen', 'ruta', 'nombre', 'extension', 'tipo', 'tamaño', 'Gb', 'fechamod', 'contar', 'error'])

    discos = unidades['volumen'].sort_values()
    try:
        with pd.ExcelWriter(app + '.xlsx', mode='a', if_sheet_exists='replace') as writer:
            unidades.to_excel(writer, sheet_name='Unidades', index=False)
            directorios.to_excel(writer, sheet_name='Directorios', index=False)
            for disco in discos:
                ficheros[ficheros['volumen'] == disco].to_excel(writer, sheet_name='Fic. ' + disco, index=False)
    except:
        with pd.ExcelWriter(app + '.xlsx', mode='w') as writer:
            unidades.to_excel(writer, sheet_name='Unidades', index=False)
            directorios.to_excel(writer, sheet_name='Directorios', index=False)
            for disco in discos:
                ficheros[ficheros['volumen'] == disco].to_excel(writer, sheet_name='Fic. ' + disco, index=False)


seg = int(time.time() - tiempo_ini)
tiempo = 'Tiempo grabación Excel '+ str(seg // 60) + "'" + str(seg % 60) + '"'
print('\n', tiempo)