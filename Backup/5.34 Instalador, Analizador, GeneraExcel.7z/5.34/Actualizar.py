###################################################################################################################################
#  Proyecto: ESPACIO, Módulo de actualización
#  ============================================
app = 'Espacio'
modulo = 'Actualizar'
#    Modulo Actualizar - Se encarga de conectar vía FTP al servidor y descargar actualizaciones
#    --------------------------------------------------------------------------------------------
version = '0.33'
#       * Modificada la creación de ficheros de arranque y ejecución para hacerla "invisible"
#
# version = '0.31'
#       * Se modifica fichero de configuración para coger uno de pruebas.
#       * Se modifica para mostrar mensaje de Script y versión al principio.
#       * Se modifica para mostrar mensaje de versión actual y versión en servidor SOLO cuando hay actualización
#
# version = '0.25'
#       * Actualizar versión si la del servidor es mayor a la parametrizada en configuración
#       * Si no existe path, actualizar actue como INSTALADOR
#           - Crea fichero .BAT en Inicio (arranque)
#           - Crea directorio path y copia los módulos y configuración
#       * Módulo LeerConfig - Se incorpora csv con configuración. Leer con pandas y crear diccionario configuración
#           - Se busca el fichero en directorio .\Espacio o en el directorio del ejecutable.
# 
# version = '0.0'
#       * Conexión vía FTP al servidor 
#           - los parámetros inicialmente están incluidos en el código, hay que parametrizarlos en configuración
#       * Crear si no existe directorio Temp
#       * Descargar contenido del directorio del proyecto Espacio (app)
###################################################################################################################################


# ------------------------------------------------------------------------------------------------------------ #
from leerConfig import LeerConfig
from accesoFTP import DescargarFTP

import os



#  Comprobar si existe la ruta (directorio)
def ExisteRuta(path):
    try:
        os.stat(path)
        return True
    except:
        return False


#  Crear directorio de la app y ficheros de ejecución y arranque en Inicio
def Instalar():
    ruta = config['Ruta']['RutaArranque']
    cmd = 'cscript ' + path + app + '.vbs'
    try:
        with open(ruta + config['Ruta']['NombreArranque'], 'w') as f:
            f.write(cmd)
    except PermissionError:
        print('Se necesita permiso de administrador')
        return False
    
    try:
        os.mkdir(path)
    except:
        pass
    try:
        os.mkdir(path + app)
    except:
        pass

    cmd = 'Set WshShell = CreateObject("WScript.Shell")\nWshShell.Run chr(34) & "' + path + app + '.bat" & Chr(34), 0\nSet WshShell = Nothing'
    try:
        with open(path + app + '.vbs', 'w') as f:
            f.write(cmd)
    except PermissionError:
        pass

    cmd = '@ECHO OFF\nCLS\nCD ' + path + app + '\nActualizar.exe\nMaster.exe'
    try:
        with open(path + app + '.bat', 'w') as f:
            f.write(cmd)
    except PermissionError:
        pass

    return True




if __name__ == "__main__":
    print("Script Actualizar - Versión", version)

    #  Lectura de parámetros de configuración
    config = LeerConfig(app)

    if config != {}:
        #  Comprobar si la app está instalada, sino lo está, INSTALAR la app
        path = config['Ruta']['ruta']
    
        instalar = True
        if not ExisteRuta(path + app):
            instalar = Instalar()
            if instalar:
                modulo = 'Instalar'
    
        if instalar:
            os.chdir(path + app)
            version = config['Version'][app]

            #  Conexión FTP - Descargar ficheros del directorio app
            DescargarFTP(config, app, version, modulo)