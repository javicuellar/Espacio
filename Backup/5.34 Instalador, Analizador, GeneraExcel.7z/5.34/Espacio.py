###################################################################################################################################
#  Proyecto: ESPACIO, Módulo Espacio - Analizador de Dispositivo (unidades, directorios y ficheros)
#  =================================================================================================
app = 'Espacio'
#    Modulo Espacio - Versión inicial 0.0
#    ---------------------------------------
version = '0.34'
#       * Corrección de errores
#
# version = '0.31'
#       * Se modifica fichero de configuración para coger uno de pruebas.
#       * Se modifica la descarga y subida al Servidor para solo realizarla en Real (no en pruebas).
#
# version = '0.25'
#       * Se cambia la lectura del fichero de configuración de google sheets al fichero CSV
#       * Se modifica el componente lectura para leer siempre todas las particiones y las unidades de red mapeadas.
#           Antes sólo se leían las particiones cuando se ejecutaba como administrador.
#       * Se descarga la BBDD del servidor antes de la ejecución y se suben los cambios al servidor al terminar
#
# version = '0.0'
#       * Crea instancia de Dispositivo para leer los dispositivos conectados al sistema
###################################################################################################################################
from leerConfig import LeerConfig
from accesoFTP import DescargarBBDD, SubirBBDD
from lectura import *

import os



print("Script Espacio - Versión", version, "  ", datetime.now().strftime("%d/%m/%Y %H:%M"))

#  Carga de diccionarios de Configuración
config = LeerConfig(app)

if config != {}:
    path = config['Ruta']['ruta'] + app
    os.chdir(path)

    if config['Pruebas']['Entorno'] == 'Real':
        #  Descargamos del Servidor la BBDD
        bd = config['Ruta']['Almacen']
        if not DescargarBBDD(config, app, bd):
            os.remove(bd)
    
    #  Analizar dispositivo
    disp = Dispositivo(config)
    del disp
    
    if config['Pruebas']['Entorno'] == 'Real':
        #  Subir al Servidor la BBDD
        SubirBBDD(config, app, bd)