###################################################################################################################################
#  Analisis de dispositivo: unidades, directorios y ficheros
#  ==========================================================
#   * Analizar la información.- búsqueda patrones (etiquetas), duplicados, basura (a borrar), etc.
#   * Informe.- sacar informes excel para su "preanálisis"
#   * Actualizar información BD
#       * Comparar.- nuevos, modificados y eliminados (almacenar cambios, cómo ??)
###################################################################################################################################
import pandas as pd




def AgruparTamaño(df):
	# dirAgrup = df[df['Abierta'] == 'A']
	dfAgrup = df.groupby(['ruta'])['tamaño'].agg(['sum', 'count'])
	#dfActivos.reset_index(inplace=True)
	print(dfAgrup)


def Comparar(df1, df2):
    print(df1.compare(df2, align_axis=0))


def Restar(df1, df2, columna):
    return df2.set_index(columna).subtract(df1.set_index(columna))


def FusionarDiferenciasDir(df1, df2):
    dfDif = pd.merge(df1, df2, how= 'outer', indicator = 'Cambio')
    df1 = dfDif.loc[dfDif['Cambio'] == 'left_only']
    df2 = dfDif.loc[dfDif['Cambio'] == 'right_only']
    df = pd.merge(df1, df2, on= ['volumen', 'ruta'], how= 'outer', suffixes=('_ant', '_nue'), indicator = 'Cambios')
    df['Cambios'] = df['Cambios'].apply(lambda i: 'Modificado' if i == 'both' else ('Eliminado' if i == 'left_only' else 'Nuevo'))
    return df.drop(columns=['Cambio_ant', 'Cambio_nue'])


def FusionarDiferenciasFile(df1, df2):
    dfDif = pd.merge(df1, df2, how= 'outer', indicator = 'Cambio')
    df1 = dfDif.loc[dfDif['Cambio'] == 'left_only']
    df2 = dfDif.loc[dfDif['Cambio'] == 'right_only']
    df = pd.merge(df1, df2, on= ['volumen', 'ruta', 'fichero'], how= 'outer', suffixes=('_ant', '_nue'), indicator = 'Cambios')
    df['Cambios'] = df['Cambios'].apply(lambda i: 'Modificado' if i == 'both' else ('Eliminado' if i == 'left_only' else 'Nuevo'))
    return df.drop(columns=['Cambio_ant', 'Cambio_nue'])


def Filtrar_Contenido(df):
    #  Selecciona sólo datos que volumen contenga CLOUD
    volumenCLOUD = df[df.volumen.str.contains('CLOUD')]


def AnalizarCambiosUnidad(df1, df2):
    df = Restar(df1.drop(columns=['equipo', 'tipo', 'tiempo', 'fecha']), df2.drop(columns=['equipo', 'tipo', 'tiempo', 'fecha']), 'volumen')
    df['volumen'] = df2['volumen'].iloc[0]
    df['fecha'] = df2['fecha'].iloc[0]
    return df


def AnalizarCambiosDirectorios(df1, df2):
    fecha = df2['fecha'].iloc[0]
    df1 = df1.drop(columns=['error', 'fecha', 'equipo', 'numdir', 'numfich'])
    df2 = df2.drop(columns=['error', 'fecha', 'equipo', 'numdir', 'numfich'])
    df1 = FusionarDiferenciasDir(df1, df2)
    df1['fecha'] = fecha
    return df1


def AnalizarCambiosFicheros(df1, df2):
    fecha = df2['fecha'].iloc[0]
    df1['fichero'] = df1['nombre'] + df1['extension']
    df2['fichero'] = df2['nombre'] + df2['extension']
    df1 = df1.drop(columns=['nombre', 'extension', 'tipo', 'error', 'fecha', 'equipo'])
    df2 = df2.drop(columns=['nombre', 'extension', 'tipo', 'error', 'fecha', 'equipo'])
    df = FusionarDiferenciasFile(df1, df2)
    df['fecha'] = fecha
    return df


# Agregar hoja a excel existente
def GrabarExcel(app, unidades, directorios, ficheros):
    discos = ficheros['volumen'].unique().sort_values()
    #  Error por sobrepasar los MAXIMOS de hoja en ficheros
    #  Plantear sacar ficheros por unidad, una pestaña por unidad ¿?
    try:
        with pd.ExcelWriter(app + '.xlsx', mode='a', if_sheet_exists='replace') as writer:
            unidades.to_excel(writer, sheet_name='Unidades', index=False)
            directorios.to_excel(writer, sheet_name='Directorios', index=False)
            #ficheros.to_excel(writer, sheet_name='Ficheros', index=False)
            for disco in discos:
                ficheros[ficheros['volumen'] == disco].to_excel(writer, sheet_name='Fic. ' + disco, index=False)
    except:
        with pd.ExcelWriter(app + '.xlsx', mode='w') as writer:
            unidades.to_excel(writer, sheet_name='Unidades', index=False)
            directorios.to_excel(writer, sheet_name='Directorios', index=False)
            #ficheros.to_excel(writer, sheet_name='Ficheros', index=False)
            for disco in discos:
                ficheros[ficheros['volumen'] == disco].to_excel(writer, sheet_name='Fic. ' + disco, index=False)





if __name__ == "__main__":
    #  Pruebas del módulo
    # --------------------------------------------------------------------------------------------------------------------------------
    from bdSqlite import *

    bd = BaseDatos('.\Espacio\Espacio.db')
	
    GrabarExcel('.\Espacio\Espacio', bd.LeerUnidades(), bd.LeerDirectorios(), bd.LeerFicheros())