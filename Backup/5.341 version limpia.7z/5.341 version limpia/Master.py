###################################################################################################################################
#  Proyecto: ESPACIO, Módulo MASTER - Módulo director para ejecución del proyecto Espacio 
#  ========================================================================================
app = 'Espacio'
modulo = 'Master'
#    Modulo Master - Versión inicial 0.0
#    ---------------------------------------
version = '5.341'
#       * Limpiamos la versión 5.34 = 0.34, dejando únicamente los fuentes necesarios
#
# version = '0.31'
#       * Se modifica fichero de configuración para coger uno de pruebas.
#       * Se modifica el módulo a ejecutar en la configuración para añadir la extensión
#
# version = '0.2'
#       * Módulo LeerConfig - Se incorpora csv con configuración. Leer con pandas y crear diccionario configuración
#       * Lectura del directorio de trabajo de configuración
#       * Leer los módulos a ejecutar de la configuración
#       * Se incorpora funcionalidad para actualizar el módulo Actualizar
#
# version = '0.0'
#       * Define el directorio de trabajo y se posiciona en él 
#       * Ejecución del módulo Espacio, lectura y análisis de dispositivos conectados
#           - los módulos a ejecutar deben estar parametrizados en la Configuración, inicialmente están en el código
###################################################################################################################################
from leerConfig import LeerConfig

import os, subprocess



print("Script Master - Versión", version)

config = LeerConfig(app)

#  Se posiciona en el directorio de trabajo
path = config['Ruta']['ruta'] + app
os.chdir(path)


#  Actualizar móduo Actualizar
import Actualizar
if config['Version'][Actualizar.modulo] == 'SI':
    Actualizar.DescargarFTP(config, app, Actualizar.version, modulo)


#  Ejecutamos los módulos parametrizados en la Configuración
for modulo in config['Master']:
    script = modulo
    
    try:
        subprocess.run([script])
    except:
        print(f"Módulo {script} no encontrado.")