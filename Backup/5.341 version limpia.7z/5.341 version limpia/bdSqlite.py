import sqlite3, os
import pandas as pd
from funciones import *





#  La clase BaseDatos implementa el software de mantenimiento de la base de datos Almacen
#     - tabablas: Dispositivos, Unidades, Directorios y Ficheros.
class BaseDatos:
    def __init__(self, ficheroBD):
        # Comprobamos si la base de datos existe ya, en caso contrario hay que crearla. 
        # Esto, por supuesto, ocurrirá la primera vez que se ejecute el programa.
        if not os.path.exists(ficheroBD):
            self.bd = sqlite3.connect(ficheroBD)
            
            # Una vez creado y conectado el archivo, hemos de crear las tablas
            self.bd.execute('''CREATE TABLE Dispositivos (fecha timestamp, equipo text, 
                sistema text, so text, maquina text, arquitectura text, procesador text)''')

            self.bd.execute('''CREATE TABLE Unidades (fecha timestamp, equipo text, volumen text, 
                tipo text, total int, usado int, porcentaje float, libre int, tiempo text)''')

            self.bd.execute('''CREATE TABLE Directorios (fecha timestamp, equipo text, volumen text, ruta text, 
                tamaño int, fechamod timestamp, numdir int, numfich int, error text)''')

            self.bd.execute('''CREATE TABLE Ficheros (fecha timestamp, equipo text, volumen text, ruta text, nombre text, extension text, 
                tipo text, fechamod timestamp, tamaño int, error text)''')
            
            self.bd.execute('''CREATE TABLE CambiosUnidades (fecha TEXT, volumen TEXT, 
                total INTEGER, usado INTEGER, porcentaje float, libre INTEGER)''')
            
            self.bd.execute('''CREATE TABLE CambiosDirectorios (fecha TEXT, volumen TEXT, ruta TEXT, Cambios TEXT,
                fechamod_ant TEXT, tamaño_ant INTEGER, fechamod_nue TEXT, tamaño_nue INTEGER)''')
            
            self.bd.execute('''CREATE TABLE CambiosFicheros (fecha TEXT, volumen TEXT, ruta TEXT, fichero TEXT,
                Cambios TEXT, fechamod_ant TEXT, tamaño_ant INTEGER, fechamod_nue TEXT, tamaño_nue INTEGER)''')
        else:
            self.bd = sqlite3.connect(ficheroBD)


    def LeerDispositivo(self, equipo):
        # Esta función se encargará de devolver un dataframe con las unidades
        sql = 'SELECT * FROM dispositivos WHERE equipo = "' + equipo + '";'
        return self.bd.execute(sql).fetchall()


    def ExisteDispositivo(self, equipo):
        #  Devuelve booleano 
        sql = 'SELECT * FROM dispositivos WHERE equipo = "' + equipo + '";'
        return self.bd.execute(sql).fetchall() != []


    def GrabarDispositivo(self, inf_dispositivos):
        self.bd.executemany("INSERT INTO Dispositivos values (?,?,?,?,?,?,?);", inf_dispositivos)
        self.bd.commit()


    def ActualizarDispositivo(self, equipo, fecha):
        sql = 'UPDATE Dispositivos SET fecha = "' + fecha + '" WHERE equipo = "' + equipo + '";'
        self.bd.execute(sql)
        self.bd.commit()


    def ExisteUnidad(self, volumen):
        #  Devuelve booleano 
        sql = 'SELECT * FROM Unidades WHERE volumen = "' + volumen + '";'
        return self.bd.execute(sql).fetchall() != []


    def LeerUnidad(self, volumen):
        # Esta función se encargará de devolver un dataframe con las unidades
        sql = 'SELECT * FROM unidades WHERE volumen = "' + volumen + '";'
        return pd.read_sql_query(sql, self.bd)


    def LeerUnidades(self):
        # Esta función se encargará de devolver un dataframe con las unidades
        sql = 'SELECT * FROM unidades'
        return pd.read_sql_query(sql, self.bd)


    def EliminarUnidad(self, volumen):
        sql = 'DELETE FROM Unidades WHERE volumen = "' + volumen + '";'
        self.bd.execute(sql)
        self.bd.commit()


    def GrabarUnidades(self, inf_unidades):
        self.bd.executemany("INSERT INTO Unidades values (?,?,?,?,?,?,?,?,?);", inf_unidades)
        self.bd.commit()


    def LeerDirectoriosUnidad(self, volumen):
        # Esta función se encargará de devolver los directorios de la unidad = volumen.
        sql = 'SELECT * FROM directorios WHERE volumen ="' + volumen + '";'
        return pd.read_sql_query(sql, self.bd)


    def LeerDirectorios(self):
        # Esta función se encargará de devolver todos los directorios en un dataframe
        sql = 'SELECT * FROM directorios'
        return pd.read_sql_query(sql, self.bd)


    def EliminarDirectorios(self, volumen):
        sql = 'DELETE FROM Directorios WHERE volumen = "' + volumen + '";'
        self.bd.execute(sql)
        self.bd.commit()


    def GrabarDirectorios(self, inf_directorios):
        self.bd.executemany("INSERT INTO Directorios values (?,?,?,?,?,?,?,?,?)", inf_directorios)
        self.bd.commit()


    def LeerFicherosUnidad(self, volumen):
        # Esta función se encargará de devolver los ficheros de la unidad = volumen.
        sql = 'SELECT * FROM ficheros WHERE volumen="' + volumen + '";'
        return pd.read_sql_query(sql, self.bd)


    def LeerFicheros(self):
        # Esta función se encargará de devolver todos los ficheros en un dataframe
        sql = 'SELECT * FROM ficheros'
        return pd.read_sql_query(sql, self.bd)


    def EliminarFicheros(self, volumen):
        sql = 'DELETE FROM Ficheros WHERE volumen = "' + volumen + '";'
        self.bd.execute(sql)
        self.bd.commit()


    def GrabarFicheros(self, inf_ficheros):
        self.bd.executemany("INSERT INTO Ficheros values (?,?,?,?,?,?,?,?,?,?)", inf_ficheros)
        self.bd.commit()


    def Grabar_cambios(self, df, tabla):
        # Escribe los datos del nuevo DataFrame en una nueva tabla en SQLite
        if 'tamaño_x' in df.columns:
            nuevos_nombres = {'tamaño_x':'tamaño_ant', 'fechamod_x':'fechamod_ant',
                              'tamaño_y':'tamaño_nue', 'fechamod_y':'fechamod_nue'}
            df = df.rename(columns=nuevos_nombres)

        df.to_sql(tabla, self.bd, index=False, if_exists='append')   #, if_exists="replace")
        self.bd.commit()



    def __del__(self):
        # Al eliminar el objeto se ejecuta este código que cierra la base de datos
        self.bd.close()
