#  Proyecto ESPACIO - Analizador de Dispositivo (unidades, directorios y ficheros)
#  ===============================================================================
from lectura import *




#  Analizar/leer dispositivo
def Analizar_Dispositivo():
	disp = Dispositivo()

	#  Borramos la variable
	del disp


if __name__ == "__main__":
	#  Analizar dispositivo
	Analizar_Dispositivo()
